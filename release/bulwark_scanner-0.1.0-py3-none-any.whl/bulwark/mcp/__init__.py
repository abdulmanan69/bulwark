"""MCP protocol client."""
