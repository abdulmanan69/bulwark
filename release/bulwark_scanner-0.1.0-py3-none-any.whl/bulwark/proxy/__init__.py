"""Runtime guard proxy."""
